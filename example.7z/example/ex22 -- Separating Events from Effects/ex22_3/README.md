# NOTICE
> [!WARNING]
> Note that these API are in experimental.
>
> [`useEffectEvent`](https://react.dev/reference/react/experimental_useEffectEvent)