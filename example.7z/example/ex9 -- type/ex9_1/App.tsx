type Status = "idle" | "loading" | "success" | "error";

const [status, setStatus] = useState<Status>("idle");