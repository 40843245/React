import { useState } from 'react';
import { sculptureList } from './data.js';

export default function Gallery() {

  /// To declare a state variable in React use `useState` which is analogous to by remember in Jetpack Compose in Android.
  /// Analogous to Jetpack Compose, 
  // it can be written as `var index by remember { mutableStateOf(0)}` in the statement `const [index, setIndex] = useState(0);`
  /// while it can be written as `index = index + 1` in the statement `setIndex(index + 1);`.
  /// index is a state variable
  /// setIndex is a setter method of index.
  /// 0 is initial value of the state variable `index`.
  const [index, setIndex] = useState(0);

  function handleClick() {
    setIndex(index + 1);
  }

  let sculpture = sculptureList[index];
  return (
    <>
      <button onClick={handleClick}>
        Next
      </button>
      <h2>
        <i>{sculpture.name} </i> 
        by {sculpture.artist}
      </h2>
      <h3>  
        ({index + 1} of {sculptureList.length})
      </h3>
      <img 
        src={sculpture.url} 
        alt={sculpture.alt}
      />
      <p>
        {sculpture.description}
      </p>
    </>
  );
}
