export default function SearchButton({ onClick }) {
    return (
      <button onClick={onClick}>
        Search
      </button>
    );
  }
  