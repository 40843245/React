# NOTICE
? It is correct that `createConnection` is a dependency. 

However, this code is a bit fragile because someone could edit the App component to pass an inline function as the value of this prop. 

In that case, its value would be different every time the App component re-renders, so the Effect might re-synchronize too often. 

To avoid this, you can pass isEncrypted down instead.