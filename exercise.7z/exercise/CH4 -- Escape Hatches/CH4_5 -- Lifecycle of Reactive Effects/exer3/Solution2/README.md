# Official solution
This solution is better than my answer (in `../Solution1/App.js`).