# issue
## reason of issue
Since we use a state variable in an asynchronous operation (here, is `setTimeout` function), 

it always access the older value of state variable, causing this issue.

```
// ...

const [text, setText] = useState('');

// ...

  function handleSend() {
    setTimeout(() => {
      alert('Sending: ' + text); // <-- Cause this issue.
    }, 3000);
  }

// ...
```

> [!TIP]
> State variable works [like a snapshot](https://react.dev/learn/state-as-a-snapshot), so you can’t read the latest state from an asynchronous operation like a timeout.


## solve the issue
To solve the issue, use a variable that is referenced (through declaring it with `useRef` function).

For more details, take a glance at `/Solution1/App.js` and `/Solution2/App.js`.