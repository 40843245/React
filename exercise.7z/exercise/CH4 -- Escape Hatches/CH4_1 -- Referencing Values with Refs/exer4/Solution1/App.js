import { useState, useRef } from 'react';

export default function Chat() {
  const [text, setText] = useState('');
  const textRef = useRef('');
  
  function handleSend() {
    setTimeout(() => {
      alert('Sending: ' + textRef.current);
    }, 3000);
  }

  function handleOnChange(e){
    setText(e.target.value);
    textRef.current = e.target.value;
  }
  
  return (
    <>
      <input
        value={text}
        onChange={e => handleOnChange(e)}
      />
      <button
        onClick={handleSend}>
        Send
      </button>
    </>
  );
}
