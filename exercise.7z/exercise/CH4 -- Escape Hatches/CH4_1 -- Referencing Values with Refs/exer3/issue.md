# issue
## reason of issue
Obviously, issue is caused by `timeoutID` instance is share between these three components 

through declaring a global variable `timeoutID`.

```
// ...

let timeoutID = 0; // <-- Cause the issue.

function DebouncedButton({ onClick, children }) {
    //...
}
```

## solve the issue
To solve the issue, declaring it at component (in `DebouncedButton` function). 

We can directly declaring a variable in in `DebouncedButton` function (as in `/Solution1/App.js`).

Or declaring a variable which takes a reference (through `useRef` function) (as in `/Solution2/App.js`).