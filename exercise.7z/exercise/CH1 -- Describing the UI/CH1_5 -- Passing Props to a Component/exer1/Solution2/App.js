import { getImageUrl } from './utils.js';

const people = [
  {
    name:"Maria Skłodowska-Curie",
    iconSrc:'szV5sdG',
    professionDescription:"physicist and chemist",
    awardAmount:4,
    awardsDescription:"(Nobel Prize in Physics, Nobel Prize in Chemistry, Davy Medal, Matteucci Medal)",
    discoversDescription:"polonium (chemical element)"
  },
  {
    name:"Katsuko Saruhashi",
    iconSrc:'YfeOqp2',
    professionDescription:"geochemist",
    awardAmount:2,
    awardsDescription:"(Miyake Prize for geochemistry, Tanaka Prize)",
    discoversDescription:"a method for measuring carbon dioxide in seawater"
  }
]
export default function Gallery() {
  return (
    <div>
      <h1>Notable Scientists</h1>
      <Profile person={people[0]}>
      </Profile>
      <Profile person={people[1]}>
      </Profile>
    </div>
  );
}

function Profile(
  { person }
){
  return (
    <>
      <section className="profile">
        <h2>{person.name}</h2>
        <img
          className="avatar"
          src={getImageUrl(person.iconSrc)}
          alt={person.name}
          width={70}
          height={70}
        />
        <ul>
          <li>
            <b>Profession: </b> 
              {person.professionDescription}
          </li>
          <li>
            <b>Awards: {person.awardAmount}</b>
            {person.awardsDescription}
          </li>
          <li>
            <b>Discovered: </b>
            {person.discoversDescription}
          </li>
        </ul>
      </section>
    </>
  )
}