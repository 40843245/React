export default function Congratulations() {
    return (
      <h1>Good job!</h1>
    );
}  