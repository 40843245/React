/// This solution is provided by me.

/** 
 * I found regularity and thus, I simply it, 
 * through defining an Object cotaining a list of label infos, 
 * then, at top level, initialize two variables which store labels to use, provided the current value of state variable `reverse`.
 * Thus, I can directly declaring it 
 * (NOT in `../Solution1/Solution.js`, we have to consider two different cases, declaring it in branching statement or conditional operators.) 
**/

import { useState } from 'react';

const labels = [
  {
    "id":0,
    "label":"First name"
  },
  {
    "id":1,
    "label":"Last name"
  }
];
export default function App() {
  const [reverse, setReverse] = useState(false);
  const firstLabel = reverse ? labels[0] : labels[1];
  const secondLabel = reverse ? labels[1] : labels[0];
  
  let checkbox = (
    <label>
      <input
        type="checkbox"
        checked={reverse}
        onChange={e => setReverse(e.target.checked)}
      />
      Reverse order
    </label>
  );

    return (
      <>
        <Field 
          key = {firstLabel.id}
          label={firstLabel.label} 
            /> 
        <Field
          key = {secondLabel.id}
          label={secondLabel.label} 
          />
        {checkbox}
      </>
    );    
}

function Field({ key,label }) {
  const [text, setText] = useState('');
  return (
    <label key={key}>
      {label}:{' '}
      <input
        type="text"
        value={text}
        placeholder={label}
        onChange={e => setText(e.target.value)}
      />
    </label>
  );
}
